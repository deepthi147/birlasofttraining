package mobileapplication;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Customer cust = new Customer();
		List<Customer> customers = new LinkedList<>();

		boolean n = false;
		while (!n) {
			System.out.println("Select any one of the option given below");
			System.out.println("1. Add Customer");
			System.out.println("2. View all customers");
			System.out.println("3. View one Customer");
			System.out.println("4. Remove Customer");
			System.out.println("5. Exit");

			switch (scan.nextInt()) {
			case 1:
				Customer customer = new Customer();
				System.out.println("Enter your FirstName");
				customer.setFname(scan.next());
				System.out.println("Enter your LastName");
				customer.setLname(scan.next());
				System.out.println("Enter your DOB");
				customer.setDob(LocalDate.parse(scan.next()));
				System.out.println("Enter your Mobile Number");
				customer.setMobileNo(scan.next());
				System.out.println("Enter your Email");
				customer.setEmail(scan.next());
				System.out.println("Enter your Location");
				customer.setLocation(scan.next());
				customers.add(customer);
				System.out.println("Customer Added...\n");
				break;

			case 2:
				for (Customer cus : customers) {
					System.out.println(cus + "\n");
				}
				break;

			case 3:
				String name = scan.next();
				Customer c = new Customer();
				c.setFname(name);

				if (customers.indexOf(c) >= 0)
					System.out.println("Founded " + customers.get(customers.indexOf(c)) + "\n");
				else
					System.out.println("Customer not found!\n");
				break;

			case 4:

				Customer c1 = new Customer();
				String fname = scan.next();
				c1.setFname(fname);
				if (customers.indexOf(c1) >= 0)
					System.out.println("Removed " + customers.remove(customers.indexOf(c1)) + "\n");
				else
					System.out.println("Customer not found!\n");
				break;

			case 5:

				n = true;
				System.out.println("Program Ended...!!!");
				break;

			default:
				System.out.println("Invalid Input!!!\nPlease try again...\n");
			}
		}

	}
}
