package mobileapplication;

import java.time.LocalDate;

public class Customer {
	String fname;
	String Lname;
	LocalDate dob;
	String mobileNo;
	String email;
	String location;

	public Customer(String fname, String lname, LocalDate dob, String mobileNo, String email, String location) {
		super();
		this.fname = fname;
		Lname = lname;
		this.dob = dob;
		this.mobileNo = mobileNo;
		this.email = email;
		this.location = location;
	}

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return Lname;
	}

	public void setLname(String lname) {
		Lname = lname;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", Lname=" + Lname + ", dob=" + dob + ", mobileNo=" + mobileNo + ", email="
				+ email + ", location=" + location + "]";
	}

	@Override
	public boolean equals(Object obj) {
		Customer cust = (Customer) obj;
		return this.fname.equals(cust.fname);
	}

}
