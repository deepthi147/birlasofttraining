package New.java;
public abstract class Animal
{
 public  abstract  void eat();
}
interface pet
{
	void being_friendly();
}
class Dog extends Animal implements pet
{
	public void eat()
	{
		System.out.println("abcd");
	}
	public void being_friendly()
	{
		System.out.println("xyz");
	}
}
class Cat extends Animal implements pet
{
	public void eat()
	{
		System.out.println("efgh");
	}
	public void being_friendly()
	{
		System.out.println("klm");
	}
}

class Interfaces
{
public static void main(String args[])
{
  Animal a=new Dog();
  a.eat();
  ((Dog)a).being_friendly();
 Animal b=new Cat();
  b.eat();
  ((Cat)b).being_friendly();
  }
  }

