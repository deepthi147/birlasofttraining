package prime;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Buffer {

	

	public Buffer() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
	
	BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
	int a;
	System.out.println("Enter an integer");
	a=Integer.parseInt(br.readLine());
	System.out.println(+a);
	
	}

}
