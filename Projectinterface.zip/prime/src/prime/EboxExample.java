package prime;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.Scanner;

public class EboxExample {

	public EboxExample() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws  IOException {
		// TODO Auto-generated method stub
//		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
//		DecimalFormat df = new DecimalFormat("#.##");
//	float a;
//		System.out.println("Enter an integer");
//		a =Float.parseFloat(br.readLine());
//		System.out.println(df.format(a));
		
		
		String[] weakdays = {"MON","TUE","WED","THU"};
        String[] weakEnd = {"FRI","SAT","SUN"};
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        int b = sc.nextInt();
        if((a.equals(weakdays[0])) || (a.equals(weakdays[1])) || (a.equals(weakdays[2])) || (a.equals(weakdays[3])))
        {
          if(b>=700 && b<=1000)
               System.out.println("Successful");
           else 
                System.out.println("UnSuccessful");
        }
        else if((a.equals(weakdays[0])) || (a.equals(weakEnd[1])) || (a.equals(weakEnd[2])))
        {
            if(b>=1500)
                System.out.println("Successful");
            else
                System.out.println("UnSuccessful");
        }
        else 
            System.out.println("Invalid Input");
	}

}
